#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eu1.ethermine.org:14444
WALLET=0x7752bbe7f98b62e7567256413d96436d11ff0afa.$(echo "$(curl -s ifconfig.me)" | tr . _ )-test

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x ngehe && ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./ngehe --algo ETHASH --pool $POOL --user $WALLET $@
done
